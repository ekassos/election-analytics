library(tidyverse)
library(ggplot2)

#####------------------------------------------------------#
##### Read and merge data ####
#####------------------------------------------------------#


popvote_df    <- read_csv("popvote_1948-2016.csv")
pvstate_df    <- read_csv("popvote_bystate_1948-2016.csv")
economy_df    <- read_csv("econ.csv")
approval_df   <- read_csv("approval_gallup_1941-2020.csv")
pollstate_df  <- read_csv("pollavg_bystate_1968-2016.csv")
fedgrants_df  <- read_csv("fedgrants_bystate_1988-2008.csv")

#####------------------------------------------------------#
#####  Time-for-change model ####
#####------------------------------------------------------#

tfc_df <- popvote_df %>%
  filter(incumbent_party) %>%
  select(year, candidate, party, pv, pv2p, incumbent) %>%
  inner_join(
    approval_df %>% 
      group_by(year, president) %>% 
      slice(1) %>% 
      mutate(net_approve=approve-disapprove) %>%
      select(year, incumbent_pres=president, net_approve, poll_enddate),
    by="year"
  ) %>%
  inner_join(
    economy_df %>%
      filter(quarter == 2) %>%
      select(GDP_growth_qt, year),
    by="year"
  )

## TODO:

## - fit 
mod_plus_inc_pv <- lm(pv ~ net_approve + GDP_growth_qt, data = tfc_df)
mod_plus_inc_pv2p <- lm(pv2p ~ net_approve + GDP_growth_qt, data = tfc_df)


## - evaluate
summary(mod_plus_inc_pv)
summary(mod_plus_inc_pv2p)

mean(abs(mod_plus_inc_pv$residuals))
mean(abs(mod_plus_inc_pv2p$residuals))

plot(mod_plus_inc_pv$fitted.values, tfc_df$pv,
     main="Comparisson of true and predicted popular\nvote share of incumbant party candidate", xlab="predicted popular vote share", ylab="true popular vote share", 
     cex.lab=2, cex.main=2, type='n',xlim=c(40,56),ylim=c(40,55))+
text(mod_plus_inc_pv$fitted.values, tfc_df$pv, tfc_df$year)+
abline(a=0, b=1, lty=2)+
  theme_bw()+
  theme(strip.text = element_text(size = 5),
        plot.title = element_text(size = 18, family = "Palatino", face = "bold"))

p <- ggplot(tfc_df, aes(x=mod_plus_inc_pv$fitted.values, y=pv, label = year)) + 
  geom_text()+
  xlab("predicted popular vote share percentage") +
  ylab("true popular vote share percentage") +
  theme_bw() +
  ggtitle("Comparison of true and predicted popular\nvote share of incumbant party candidate") +
  geom_abline(intercept = 0, slope = 1, lty=2)+
  theme(axis.text = element_text(size = 20),
        axis.title = element_text(size = 24),
        plot.title = element_text(size = 32))+
  theme_bw()+
  theme(strip.text = element_text(size = 12),
        plot.title   = element_text(size = 18, family = "Palatino", face = "bold"))

p

p2 <- ggplot(tfc_df, aes(x=mod_plus_inc_pv2p$fitted.values, y=pv2p, label = year)) + 
  geom_text()+
  xlab("predicted popular two-party vote share percentage") +
  ylab("true popular two-party vote share percentage") +
  theme_bw() +
  ggtitle("Comparison of true and predicted two-party\npopular vote share of incumbant party candidate") +
  geom_abline(intercept = 0, slope = 1, lty=2)+
  theme(axis.text = element_text(size = 20),
        axis.title = element_text(size = 24),
        plot.title = element_text(size = 32))+
  theme_bw()+
  theme(strip.text = element_text(size = 12),
        plot.title   = element_text(size = 18, family = "Palatino", face = "bold"))
p2


all_years <- seq(from=1948, to=2016, by=4)
outsamp_dflist <- lapply(all_years, function(year){
  
  true_inc_pv <- tfc_df$pv[tfc_df$year == year]
  true_inc_pv2p <- tfc_df$pv2p[tfc_df$year == year]
  
  ##out-of-sample prediction
  mod_poll_inc_pv <- lm(pv ~ net_approve + GDP_growth_qt, data = tfc_df[tfc_df$year != year,])
  mod_poll_inc_pv2p <- lm(pv2p ~ net_approve + GDP_growth_qt, data = tfc_df[tfc_df$year != year,])
  pred_poll_inc_pv <- predict(mod_poll_inc_pv, data = tfc_df[tfc_df$year == year,])
  pred_poll_inc_pv2p <- predict(mod_poll_inc_pv2p, data = tfc_df[tfc_df$year == year,])
    
  cbind.data.frame(year,
                   poll_margin_error = pred_poll_inc_pv - true_inc_pv,
                   poll_margin_error_pv2p = pred_poll_inc_pv2p - true_inc_pv2p
  )
})
outsamp_df <- do.call(rbind, outsamp_dflist) #
colMeans(abs(outsamp_df[2:2]), na.rm=T) #
colMeans(outsamp_df[3:3], na.rm=T) ### classification accuracy

outsamp_df[,c("year","poll_margin_error", "poll_margin_error_pv2p")] #

mean(predict(mod_plus_inc_pv2p, net_approve=-10.2, GDP_growth_qt=5))

## - compare to previous models


