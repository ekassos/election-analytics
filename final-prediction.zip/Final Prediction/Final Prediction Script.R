library(tidyverse)
library(ggplot2)
library(dplyr)

polls_data <- read_csv("president_polls.csv")
poll_results <- data.frame(state = character(), pred_DEM = double(), pred_REP = double(), differ = double())
for (state_name in state.name) {
  print(state_name)

dem_dat <- polls_data %>% 
  filter(candidate_party == "DEM") %>%
  filter(state == state_name)

dem_dat <- dem_dat %>% 
  mutate(scaled_pct = ((fte_num_grade/sum(fte_num_grade) * pct)*0.4+0.6*(log(days_till_election)/sum(log(days_till_election))))

DEM <- sum(dem_dat$scaled_pct)

rep_dat <- polls_data %>% 
  filter(candidate_party == "REP") %>%
  filter(state == state_name)

rep_dat <- rep_dat %>% 
  mutate(scaled_pct = ((fte_num_grade/sum(fte_num_grade)) * pct))

REP <- sum(rep_dat$scaled_pct)

poll_results %>% 
  add_row(state = state_name,  pred_DEM = DEM, pred_REP = REP, differ = abs(DEM-REP))
}
