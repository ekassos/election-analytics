#### Economy ####
#### Gov 1347: Election Analysis (2020)
#### TFs: Soubhik Barari, Sun Young Park

####----------------------------------------------------------#
#### Pre-amble ####
####----------------------------------------------------------#

## install via `install.packages("name")`
library(tidyverse)
library(ggplot2)

## set working directory here
setwd("~")

####----------------------------------------------------------#
#### The relationship between economy and PV ####
####----------------------------------------------------------#

economy_df <- read_csv("updated_econ.csv") 
popvote_df <- read_csv("popvote_1948-2016.csv") 

dat <- popvote_df %>% 
  filter(incumbent_party == TRUE) %>%
  select(year, winner, pv2p) %>%
  left_join(economy_df %>% filter(quarter == 2))

new_dat <- popvote_df %>% 
  filter(incumbent_party == TRUE) %>%
  select(year, winner, pv2p) %>%
  left_join(economy_df %>% filter(quarter == 3))

## scatterplot + line
dat %>%
  ggplot(aes(x=GDP_growth_qt, y=pv2p,
             label=year)) + 
  geom_text() +
  geom_smooth(method="lm", formula = y ~ x) +
  geom_hline(yintercept=50, lty=3) +
  geom_vline(xintercept=0.01, lty=3) +
  xlab("Second quarter GDP growth") +
  ylab("Incumbent party's\nnational popular vote") +
  ggtitle("Relationship between second quarter GDP growth in election year\nand incumbent party's national popular vote result") +
  theme_ipsum() +
  theme(strip.text = element_text(size = 14),
        plot.title   = element_text(size = 18, family = "Palatino"),
        axis.title.x = element_text(size = 13, face = "bold"),
        axis.text.x = element_text(size = 12, hjust = 0.7),
        axis.title.y = element_text(size = 13, face = "bold"))

new_dat %>%
  ggplot(aes(x=GDP_growth_qt, y=pv2p,
             label=year)) + 
  geom_text() +
  geom_smooth(method="lm", formula = y ~ x) +
  geom_hline(yintercept=50, lty=3) +
  geom_vline(xintercept=0.01, lty=3) +
  xlab("Third quarter GDP growth") +
  ylab("Incumbent party's\nnational popular vote") +
  ggtitle("Relationship between third quarter GDP growth in election year\nand incumbent party's national popular vote result") +
  theme_ipsum() +
  theme(strip.text = element_text(size = 14),
        plot.title   = element_text(size = 18, family = "Palatino"),
        axis.title.x = element_text(size = 13, face = "bold"),
        axis.text.x = element_text(size = 12, hjust = 0.7),
        axis.title.y = element_text(size = 13, face = "bold"))
## fit a model
lm_econ <- lm(pv2p ~ GDP_growth_qt, data = dat)
summary(lm_econ)

new_lm_econ <- lm(pv2p ~ GDP_growth_qt, data = new_dat)
summary(new_lm_econ)

dat %>%
  ggplot(aes(x=GDP_growth_qt, y=pv2p,
             label=year)) + 
    geom_text(size = 8) +
    ggtitle("Margin of popular vote victory in every state in 2020 election predictionn") +
    geom_smooth(method="lm", formula = y ~ x) +
    geom_hline(yintercept=50, lty=2) +
    geom_vline(xintercept=0.01, lty=2) + # median
    xlab("Q2 GDP growth (X)") +
    ylab("Incumbent party PV (Y)") +
    theme_bw() +
    ggtitle("Y = 49.44 + 2.969 * X") + 
    theme(axis.text = element_text(size = 20),
          axis.title = element_text(size = 24),
          plot.title = element_text(size = 32))+
    theme_bw()+
    theme(strip.text = element_text(size = 12),
          plot.title   = element_text(size = 18, family = "Palatino", face = "bold"))

new_dat %>%
  ggplot(aes(x=GDP_growth_qt, y=pv2p,
             label=year)) + 
  geom_text(size = 5) +
  ggtitle("Margin of popular vote victory in every state in 2020 election predictionn") +
  geom_smooth(method="lm", formula = y ~ x) +
  geom_hline(yintercept=50, lty=2) +
  geom_vline(xintercept=0.01, lty=2) + # median
  xlab("Q2 GDP growth (X)") +
  ylab("Incumbent party PV (Y)") +
  theme_bw() +
  ggtitle("Y = 51.81 + 0.2685 * X") + 
  theme_ipsum() +
  theme(strip.text = element_text(size = 10),
        plot.title   = element_text(size = 18, family = "Palatino"),
        axis.title.x = element_text(size = 13, face = "bold"),
        axis.text.x = element_text(size = 12, hjust = 0.7),
        axis.title.y = element_text(size = 13, face = "bold"))
## model fit 

summary(lm_econ)$r.squared
plot(dat$year, dat$pv2p, type="l",
     main="Comparison of true (line) and predicted (dots) incumbant party's\npopular vote data based on second quarter GDP",
     xlab="year", ylab="incumbant party popular vote percentage")
points(dat$year, predict(lm_econ, dat))

hist(lm_econ$model$pv2p - lm_econ$fitted.values,
     main="Comparisson of difference between true and predicted\nincumbant party's popular vote data based on second quarter GDP",
     xlab="Difference", ylab="Count")

mse <- mean((lm_econ$model$pv2p - lm_econ$fitted.values)^2)
sqrt(mse)

summary(new_lm_econ)$r.squared
plot(new_dat$year, new_dat$pv2p, type="l",
     main="Comparison of true (line) and predicted (dots) incumbant party's\npopular vote data based on third quarter GDP",
     xlab="year", ylab="incumbant party popular vote percentage")
points(new_dat$year, predict(new_lm_econ, new_dat))

hist(new_lm_econ$model$pv2p - new_lm_econ$fitted.values,
     main="Comparisson of difference between true and predicted\nincumbant party's popular vote data based on third quarter GDP",
     xlab="Difference", ylab="Count")

new_mse <- mean((new_lm_econ$model$pv2p - new_lm_econ$fitted.values)^2)
sqrt(new_mse)

## model testing: leave-one-out
outsamp_mod  <- lm(pv2p ~ GDP_growth_qt, dat[dat$year != 2016,])
outsamp_pred <- predict(outsamp_mod, dat[dat$year == 2016,])
outsamp_true <- dat$pv2p[dat$year == 2016] 

outsamp_pred - outsamp_true

outsamp_mod  <- lm(pv2p ~ GDP_growth_qt, new_dat[new_dat$year != 2016,])
outsamp_pred <- predict(outsamp_mod, new_dat[new_dat$year == 2016,])
outsamp_true <- new_dat$pv2p[new_dat$year == 2016] 

outsamp_pred - outsamp_true

## model testing: cross-validation (one run)
years_outsamp <- sample(dat$year, 8)
mod <- lm(pv2p ~ GDP_growth_qt,
          dat[!(dat$year %in% years_outsamp),])

outsamp_pred <- predict(mod,
                        newdata = dat[dat$year %in% years_outsamp,])  

mean(outsamp_pred - dat$pv2p[dat$year %in% years_outsamp])
## model testing: cross-validation (1000 runs)
outsamp_errors <- sapply(1:1000, function(i){
  years_outsamp <- sample(dat$year, 8)
  outsamp_mod <- lm(pv2p ~ GDP_growth_qt,
                    
                    dat[!(dat$year %in% years_outsamp),])
  
  outsamp_pred <- predict(outsamp_mod,
                          
                          newdata = dat[dat$year %in% years_outsamp,])
  outsamp_true <- dat$pv2p[dat$year %in% years_outsamp]
  mean(outsamp_pred - outsamp_true)
})
hist(outsamp_errors,
     xlab = "",
     main = "Mean out-of-sample residual for Q2 GDP prediction model\n(using 1000 runs of cross-validation)")

outsamp_errors <- sapply(1:1000, function(i){
  years_outsamp <- sample(new_dat$year, 8)
  outsamp_mod <- lm(pv2p ~ GDP_growth_qt,
                    
                    new_dat[!(new_dat$year %in% years_outsamp),])
  
  outsamp_pred <- predict(outsamp_mod,
                          
                          newdata = new_dat[dat$year %in% years_outsamp,])
  outsamp_true <- new_dat$pv2p[new_dat$year %in% years_outsamp]
  mean(outsamp_pred - outsamp_true)
})
hist(outsamp_errors,
     xlab = "",
     main = "Mean out-of-sample residual for Q3 GDP prediction model\n(using 1000 runs of cross-validation)")

## prediction for 2020
GDP_new <- economy_df %>%
    subset(year == 2020 & quarter == 2) %>%
    select(GDP_growth_qt)

predict(lm_econ, GDP_new)

predict(lm_econ, GDP_new, interval="prediction")

q3_GDP_new <- economy_df %>%
  subset(year == 2020 & quarter == 1) %>%
  select(GDP_growth_qt)

predict(new_lm_econ, q3_GDP_new)

predict(new_lm_econ, q3_GDP_new, interval="prediction")
## extrapolation?

cor(dat$GDP, dat$stock_open)
cor(dat$GDP_growth_qt, dat$GDP_growth_yr)

##   replication of: https://nyti.ms/3jWdfjp

economy_df %>%
  subset(quarter == 2 & !is.na(GDP_growth_qt)) %>%
  ggplot(aes(x=year, y=GDP_growth_qt,
             fill = (GDP_growth_qt > 0))) +
  geom_col() +
  xlab("Year") +
  ylab("GDP Growth (Second Quarter)") +
  ggtitle("The percentage decrease in G.D.P. is by far the biggest on record.") +
  theme_bw() +
  theme(legend.position="none",
        plot.title = element_text(size = 12,
                                  hjust = 0.5,
                                  face="bold"))

